from pymongo import MongoClient

#연결
client = MongoClient('mongodb://localhost:27017')
#print("DB 연결 성공")

#구조 정의
db = client['school_db']
collection = db['students']

#데이터 출력
for student in collection.find():
    print(student)

print("===============================")

#데이터 출력
result = collection.find_one({"name":"성이름"})
print(result)

print("===============================")

for student in collection.find({"age":{"$gte":20}}): #age가 20보다 크거나 같은 경우
    print(student)