from faker import Faker

fake = Faker("ko_KR")

for _ in range(20):
    print(fake.name())
    print(fake.address())
    print(fake.email())
    print(fake.phone_number())
    print(fake.credit_card_number())
    print("=============================")
