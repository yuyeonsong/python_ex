#mysql, mssql 의 경우 DB > Table > Column > Data 구조
#MongoDB의 경우 

from pymongo import MongoClient

#연결
client = MongoClient('mongodb://localhost:27017')
#print("DB 연결 성공")

#구조 정의
db = client['school_db']
collection = db['students'] #elastkcsearch에서는 document

#다중 문서 삽입
students = [
    {"name": "이영희", "age": 19, "grade": "B", "subjects": ["과학", "국어"]},
    {"name": "박민수", "age": 21, "grade": "A", "subjects": ["수학", "과학"]}
]
result = collection.insert_many(students)
print(f"삽입된 문서들 ID {result.inserted_ids}")

