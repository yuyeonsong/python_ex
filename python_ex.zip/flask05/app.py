from flask import Flask, redirect, render_template
from pymongo import MongoClient
from bson import ObjectId

app = Flask(__name__)

#연결 정보
client = MongoClient('mongodb://localhost:27017')
db = client['mydatabase_faker']
collection = db['people']

#기본 라우트 설정
@app.route('/')
def index():
    people = collection.find()
    return render_template('list.html', people=people)

@app.route('/delete_user/<user_id>')
def delete_user(user_id):
    collection.delete_one({'_id' : ObjectId(user_id)})
    return redirect('/') #return index()로도 사용할 수 있다.

if __name__ == "__main__":
    app.run(debug=True)
