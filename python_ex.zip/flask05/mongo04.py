from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client['school_db']
collection = db['students']

# 단일 문서 삭제 (이름이 박민수인 학생 삭제)
result = collection.delete_one({"name": "박민수"})
print(f"삭제된 문서 수: {result.deleted_count}")

# 여러 문서 삭제 (나이가 19인 학생들 삭제)
result = collection.delete_many({"age": 19})
print(f"삭제된 문서 수: {result.deleted_count}")

for student in collection.find():
    print(student)