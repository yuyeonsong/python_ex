from pymongo import MongoClient

#연결
client = MongoClient('mongodb://localhost:27017')

#구조 정의
db = client['school_db']
collection = db['students']

#데이터 수정하기(최상단 1개만)
result = collection.update_one(
    {"name": "박민수"},
    {"$set":{"grade":"A+"}}
)

print(f"수정된 문서 수: {result.modified_count}")
print("===========================")

#많은 데이터를 수정하기
result = collection.update_many(
    {"subjects": "수학"},
    {"$set":{"grade":"A+"}}
)


for student in collection.find():
    print(student)