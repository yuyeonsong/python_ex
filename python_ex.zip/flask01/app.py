#메인 뼈대
from flask import Flask, render_template, request
import feedparser

app = Flask(__name__)

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/rss", methods=['GET', 'POST'])
def rss():
    rss_url = request.form['rss_url']
    feed = feedparser.parse(rss_url)
    print(feed) #넣은 url의 내용을 파싱 #https://www.dailysecu.com/rss/allArticle.xml
    return render_template('rss.html', feed=feed) 

if __name__ == '__main__':
    app.run(debug=True) #개발자 모드