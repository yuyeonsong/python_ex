#pip install python-docx docx2pdf

from docx import Document
from docx2pdf import convert

name = input("이름을 입력하세요.")
course = input("과정명을 입력하세요.")
date = input("날짜를 입력하세요.")

doc = Document("template.docx")

for paragraph in doc.paragraphs: #paragraph 단락
    #print(paragraph.text)
    if 'NAME' in paragraph.text:
        paragraph.text = paragraph.text.replace('NAME', name) #NAME값을 입력받은 name으로 replace
        
    elif 'COURSE' in paragraph.text:
        paragraph.text = paragraph.text.replace('COURSE', course)
    
    elif 'DATE' in paragraph.text:
        paragraph.text = paragraph.text.replace('DATE', date)

doc.save('result.docx')
convert('result.docx', 'result.pdf')