import requests
from bs4 import BeautifulSoup

keyword = input("키워드 입력: ")
url = f"https://kin.naver.com/search/list.naver?query={keyword}"
#https://kin.naver.com/serach/list.naver?query={keyword}

#크롤링 탐지 방지
header_info = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0'}
r = requests.get(url, headers=header_info, verify=False) #get요청
soup = BeautifulSoup(r.text, 'html.parser')

#select 방식 copy
titles = soup.select("#s_content > div.section > ul > li > dl > dt > a")
dates = soup.select("#s_content > div.section > ul > li > dl > dd.txt_inline")

#두개라서 for 구문을 동시에 쓰기 힘들 경우 zip()함수 사용
for title, date in zip(titles, dates):
    print(f"질문: {title.text}")
    print(f"날짜: {date.text}")

print(soup.text)