import ftplib

hostname = "192.168.244.128" #내아이피
ftp = ftplib.FTP(hostname)
ftp.login('msfadmin','msfadmin')

#현재위치
print(ftp.pwd()) 
#디렉토리, 파일 이름 출력
ftp.retrlines('LIST')
print("====================")
#디렉토리 생성하기
#ftp.mkd("new_folder")
#디렉토리 삭제하기
#ftp.rmd("new_folder")
#출력
#ftp.retrlines('LIST')
print("====================")
#vulnerable 디렉토리로 이동
ftp.cwd("vulnerable")
ftp.retrlines('LIST')

ftp.quit()

