import os
files = os.listdir('.') #'.'은 현재 디렉토리
print(files)
print(type(files)) #type()은 디버깅, 함수 알기 위해 사용하는 함수

for file in files: #전체 파일 출력
    print(file)

for i in range(3): #범위 내 파일 출력
    print(files[i])

my_list = [10, 20, 30, 40, 50]
my_list[1] = 25  # 두 번째 요소 값을 25로 수정
print(my_list)  # 결과: [10, 25, 30, 40, 50]

my_list[4] = 100  # 다섯 번째 요소 값을 100으로 수정
print(my_list)  # 결과: [10, 25, 30, 40, 100]

my_list.append(6)  # 리스트 끝에 6 추가
print(my_list)

my_list.insert(1, 9)  # 인덱스 1에 9 삽입
print(my_list)

my_list.remove(30) # 데이터값 30 삭제
print(my_list)

del my_list[0]  # 첫 번째 인덱스 기준 요소 삭제
print(my_list)
