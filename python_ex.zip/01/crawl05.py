import requests
from bs4 import BeautifulSoup

url = "https://www.malware-traffic-analysis.net/2023/index.html"

#크롤링 탐지 방지
header_info = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0'}
r = requests.get(url, headers=header_info, verify=False) #get요청
soup = BeautifulSoup(r.text, 'html.parser')

tags = soup.select("#main_content > div.content > ul > li > a.main_menu")

results = []
for tag in tags:
    link_text = tag.text
    link_href = f"https://www.malware-traffic-analysis.net/2023/{tag.get('href')}"
    results.append(f"{link_text}\n{link_href}\n\n")
    #print(link_text)
    #print(link_href)
    print(results)

#텍스트 파일에 내용 저장
with open('malwares.txt', 'w', encoding='utf-8') as file: #w는 덮어쓰기, 추가하고싶으면 a사용
    for result in results:
        file.write(result)

