import feedparser
import pandas as pd #엑셀파일 저장용

url = "https://www.dailysecu.com/rss/allArticle.xml"

feed = feedparser.parse(url)
#print(feed)

titles = []
links = []
descriptions = []
authors = []
pubDates = []

for entry in feed.entries:
    titles.append(entry.title)
    links.append(entry.link)
    descriptions.append(entry.description)
    authors.append(entry.author)
    pubDates.append(entry.published)

#엑셀 구조
data = {'Title': titles, 'Link': links, 'Description': descriptions, 'Author': authors, "PubDate": pubDates}

#데이터프레임형태로 저장
df = pd.DataFrame(data)
#엑셀 파일로 만들기
df.to_excel('dailysecu.xlsx', index=False)

#print(titles)
print("파일이 생성 되었습니다.")