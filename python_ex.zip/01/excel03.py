from openpyxl import load_workbook
#data_only=를 사용하면 수식 대신 데이터값 출력
book = load_workbook("excel_data2.xlsx", data_only=True)
ws = book.active

#1. cell 범위 접근
#cell = ws["A1":"E7"]:

#2. cell 범위 접근(for구문)
for row in ws["A1":"E7"]:
    result = []
    #for ~ in ~으로 데이터 가져오기
    for cell in row:
        result.append(cell.value)
    print(result)


for row in ws ["A1":"E7"]:
    #리스트 컴프리헨션 사용, 리스트 방식으로 추가하겠다는 뜻
    values = [cell.value for cell in row]
    print(values)