import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication 
from dotenv import load_dotenv
import os

load_dotenv()
send_email = os.getenv("SECRET_ID")
send_pwd = os.getenv("SECRET_PASS")
recv_email = "binpageyu@naver.com" #보낼 계정

smtp = smtplib.SMTP('smtp.naver.com', 587)
smtp.ehlo()
smtp.starttls()

smtp.login(send_email,send_pwd)
  
text = f"탐지라인:"

msg = MIMEMultipart()
msg['Subject'] = f"모니터 탐지:"  
msg['From'] = send_email          
msg['To'] = recv_email

text ="<b>탐지되었습니다.</b>"

contentPart = MIMEText(text) 
msg.attach(contentPart) 

etc_file_path = r'uploads/1.txt' #보낼 파일
with open(etc_file_path, 'rb') as f : 
    etc_part = MIMEApplication( f.read() )
    etc_part.add_header('Content-Disposition','attachment', filename=etc_file_path)
    msg.attach(etc_part)

smtp.sendmail(send_email,recv_email,msg.as_string() )
smtp.quit()