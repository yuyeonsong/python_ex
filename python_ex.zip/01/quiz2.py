#ftp_crawl.py 랑 비교하기

import feedparser
import pandas as pd #엑셀파일 저장용
from openpyxl import workbook
import os
import zipfile
import ftplib

def save_rss_to_excel():
    #url = "https://www.dailysecu.com/rss/allArticle.xml"
    urls = []
    with open('list.txt', 'r') as file:
        for line in file:
            url = line.strip()
            if url:  
                urls.append(url)
    #results에 저장
    os.makedirs('results', exist_ok=True)

    for i, url in enumerate(urls, start=1):
        feed = feedparser.parse(url)

        titles = []
        links = []
        descriptions = []
        authors = []
        pubDates = []


        for entry in feed.entries:
            titles.append(entry.title)
            links.append(entry.link)
            descriptions.append(entry.description)
            authors.append(entry.author)
            pubDates.append(entry.published)

        #엑셀 구조
        data = {'Title': titles, 'Link': links, 'Description': descriptions, 'Author': authors, "PubDate": pubDates}

        #데이터프레임형태로 저장
        df = pd.DataFrame(data)

        #파일 3개 만들기
        filename = f"site{i}.xlsx"
        filepath = os.path.join('results', filename)

        #엑셀 파일로 만들기
        df.to_excel(filepath, index=False)

        print(f"저장된 파일: {filename}")

def zip_excel():
    RESULT_DIR = 'results'

    zip_file = zipfile.ZipFile('results.zip', 'w') #압축

    #압축하는 경우 listdir보단 os.walk를 사용해서 모든 하위 디렉토리, 파일 탐색
    for root, dirs, files in os.walk(RESULT_DIR):
        for file in files:
            #os.path.join()의 경로에 있는 파일을 zip에 추가
            zip_file.write(os.path.join(root, file))

    zip_file.close()

def go_ftp():
    ##FTP 서버에 결과 값을 보낸다.
    hostname = "192.168.244.128"
    ftp = ftplib.FTP(hostname)
    ftp.login('msfadmin','msfadmin')
    ftp.retrlines('LIST')

    with open("results.zip", "rb") as f:
        ftp.storbinary(f"STOR results.zip",f)

    print(f"현재작업디렉터리：{ftp.pwd()}")
    ftp.retrlines('LIST')
    ftp.quit()

if __name__ == "__main__":
    save_rss_to_excel()
    zip_excel()
    go_ftp()