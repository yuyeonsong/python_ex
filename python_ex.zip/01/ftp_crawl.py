import feedparser
import pandas as pd #엑셀파일 저장용
from openpyxl import Workbook
import os
import zipfile
import ftplib

#RSS 서비스 대상 정보 수집 및 엑셀 파일 저장
RESULT_DIR = 'results'

if not os.path.exists(RESULT_DIR):
    os.makedirs(RESULT_DIR)

with open('list.txt', 'r', encoding='utf-8') as file:
    rss_urls = file.readlines()

    for index, url in enumerate(rss_urls):
        feed = feedparser.parse(url) #crawl06.py

        titles = []
        links = []
        descriptions = []
        authors = []
        pubDates = []

        for entry in feed.entries:
            titles.append(entry.title)
            links.append(entry.link)
            descriptions.append(entry.description)
            authors.append(entry.author)
            pubDates.append(entry.published)

        #워크북
        wb = Workbook()
        ws = wb.active
        ws.title = f"{index+1}번째 Data"

        #첫번 째 행에 헤더를 작성
        headers = ['Title', 'Link', 'Description', 'Author', 'Published']
        ws.append(headers)

        #데이터 행 단위 저장
        for i in range(len(titles)):
            ws.append([titles[i], links[i], descriptions[i], authors[i], pubDates[i]])

        # 엑셀 파일로 저장
        file_path = os.path.join(RESULT_DIR, f'{index+1}_result.xlsx')
        wb.save(file_path)

##결과 값을 result.zip 파일로 저장
zip_file = zipfile.ZipFile("result.zip", "w")

for root, dirs, files in os.walk(RESULT_DIR):
    for file in files:
        zip_file.write(os.path.join(root, file))

zip_file.close()

##FTP 서버에 결과 값을 보낸다.
hostname = "192.168.244.128"
ftp = ftplib.FTP(hostname)
ftp.login('msfadmin','msfadmin')
ftp.retrlines('LIST')

with open("result.zip", "rb") as f:
    ftp.storbinary(f"STOR result.zip",f)

print(f"현재작업디렉터리：{ftp.pwd()}")
ftp.retrlines('LIST')
ftp.quit()