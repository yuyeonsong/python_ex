from openpyxl import Workbook

#새 엑셀 파일 만들기
wb = Workbook()
#새 시트 만들기
ws = wb.active
ws.title = "New Title"

#1.셀 직접 접근
#ws["A5"] = 4

#2. cell매서드 사용
for row in ws['A1:D4']:
    print(f"row: {row}")
    for cell in row:
        cell.value = f'{cell} Hello World!'

wb.save("test.xlsx")