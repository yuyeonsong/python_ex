import requests
from bs4 import BeautifulSoup
from openpyxl import Workbook

url = "https://www.malware-traffic-analysis.net/2023/index.html"

#크롤링방지
header_info = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'}
r = requests.get(url, headers=header_info, verify=False) #get요청,  SSL 인증서 검증off
soup = BeautifulSoup(r.text, 'html.parser')

#추출 범위 선택
tags = soup.select("#main_content > div.content > ul > li > a.main_menu")

#엑셀 파일 생성
wb = Workbook()
#엑셀 시트 활성화
ws = wb.active

#헤더 입력
ws['A1'] = "설명"
ws['B1'] = "URL 링크"

i = 2 #헤더를 비워놓기 위해 2부터 시작
#tags에 있는 추출 범위에서 <a>태그 반복
for tag in tags:
    ws.cell(row=i, column=1, value=tag.text)
    ws.cell(row=i, column=2, value=f"https://www.malware-traffic-analysis.net/2023/{tag.get('href')}")
    i = i + 1 #다음 행으로 이동

#엑셀 저장
wb.save("malwares.xlsx")