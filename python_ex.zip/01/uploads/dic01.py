person = {"name": "John", "age": 30, "city": "New York"}
print(person["name"])
print(person.get("name", 0)) #get() key값이 없는 경우 예외처리 함수

keys = person.keys()
print(keys)

values = person.values()
print(values)

items = person.items()
print(items)