# 한글로 된 텍스트 파일 -> 영어로 번역을 합니다. (10줄 이내)
# 번역된 파일을 날짜를 더해서 저장
# 이메일로 보낸다.

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication 
from dotenv import load_dotenv
import os
from datetime import datetime
from deep_translator import GoogleTranslator

# 날짜 설정
now = datetime.now()
day = now.strftime("%Y-%m-%d")
hour = now.strftime("%H-%M-%S")  # ":" → "-" (파일명에 사용 불가)
timestamp = f"{day}_{hour}"

# 환경 변수 로딩
load_dotenv()
send_email = os.getenv("SECRET_ID")
send_pwd = os.getenv("SECRET_PASS")
recv_email = "binpageyu@naver.com"

# 번역 수행
input_path = 'uploads/3.txt'
output_path = f"uploads/translated_{timestamp}.txt"

with open(input_path, 'r', encoding='utf-8') as file:
    lines = file.readlines()

translated_lines = []
for line in lines[:10]:  # 10줄 이내만 번역
    translated = GoogleTranslator(source='ko', target='en').translate(line.strip())
    translated_lines.append(translated)

# 번역 결과 저장
with open(output_path, 'w', encoding='utf-8') as file:
    file.write('\n'.join(translated_lines))

# 메일 준비
smtp = smtplib.SMTP('smtp.naver.com', 587)
smtp.ehlo()
smtp.starttls()
smtp.login(send_email, send_pwd)

msg = MIMEMultipart()
msg['Subject'] = f"탐지 보고서 - {day}"  
msg['From'] = send_email          
msg['To'] = recv_email

text = "<b>탐지된 텍스트가 영어로 번역되어 첨부되었습니다.</b>"
msg.attach(MIMEText(text, 'html'))

# 첨부파일 (번역 결과)
with open(output_path, 'rb') as f:
    part = MIMEApplication(f.read())
    part.add_header('Content-Disposition', 'attachment', filename=os.path.basename(output_path))
    msg.attach(part)

# 메일 전송
smtp.sendmail(send_email, recv_email, msg.as_string())
smtp.quit()
