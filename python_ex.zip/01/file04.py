import os
import time
from datetime import datetime

dir_path = "uploads"
pre_file = set(os.listdir(dir_path)) #업로드폴더 내 기존 파일 출력

#현재 리스트에서 기존 리스트 제외하면 새로운 파일 확인 가능
while True:
    #날짜 표시
    now = datetime.now()
    #now 포맷팅하기
    day = now.strftime("%Y-%m-%d")
    hour = now.strftime("%H:%M:%S")

    current_file = set(os.listdir(dir_path))
    result_diff = current_file - pre_file #내용이 쌓임


    for file_name in result_diff:
        print(f"새로운 파일 탐지: {file_name}")
        with open(f"{day}_탐지_보고서.txt", "a", encoding="UTF-8") as file:
            file.write(f"작성자: 정유빈\n")
            file.write(f"주요내용: 신규 파일 탐지 내역\n")
            file.write(f"시간: {hour}, 파일이름: {file_name}\n\n")
            #file.write(f"======================")

    pre_file =  current_file #기존 파일에 넣어주면 result_diff는 항상 새로운 파일만 출력
    print("파일 모니터링 중!")
    time.sleep(1) #1초마다
