from openpyxl import Workbook

#새 엑셀 파일 만들기
wb = Workbook()
#새 시트 만들기
ws = wb.active
ws.title = "New Title"

#3. cell() 메서드 사용
for i in range(10):
    row_cell = ws.cell(row=(i+1), column=1)
    row_cell.value = str(i+1) + "번째 데이터 저장"

wb.save("test02.xlsx")