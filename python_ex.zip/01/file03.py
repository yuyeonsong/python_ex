import os

dir_path = "uploads"
all_files = os.listdir(dir_path)

txt_files = []

for file in all_files:
    if file.endswith(".txt"):
        txt_files.append(file)

#찾아낸 파일을 열기 위해서는 경로를 알려줄 필요가 있다
#1.txt, 2.txt /uploads/1.txt
for filename in txt_files:
    file_path = os.path.join(dir_path, filename)
    with open(file_path, 'r', encoding='utf-8') as file:
        print(f"{filename} 내용:")
        print(file.read()) #print(file.readlines())랑 비교
        print("-" * 40)
