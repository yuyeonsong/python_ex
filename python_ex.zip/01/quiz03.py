import re
import os
import time
from datetime import datetime

def monitoring_uploadsdir():
    dir_path = "uploads"
    if not os.path.exists(dir_path):
        print("모니터링 대상 디렉터리가 없습니다.")
        return
    
    pre_files = set(os.listdir(dir_path)) #초기 파일 목록 기준점
    print(f"{dir_path} 디렉터리의 모니터링을 시작합니다!")

    #현재 리스트에서 기존 리스트 제외하면 새로운 파일 확인 가능
    try:
        while True:
            #날짜 표시
            now = datetime.now()
            #now 포맷팅하기
            day = now.strftime("%Y-%m-%d")
            hour = now.strftime("%H:%M:%S")

            current_files = set(os.listdir(dir_path))
            new_files = current_files - pre_files

            txt_files=[] #append쓰려면 만들어야됨
            for file in new_files:
                if file.endswith(".txt"):
                    txt_files.append(file)

            for filename in txt_files:
                file_path = os.path.join(dir_path, filename) #파일이름과 그 파일의 경로
                print(f"{day} {hour} 새로운 .txt 파일 탐지: {filename}")

                max_lines = 1000
                try:
                    with open(file_path, 'r', encoding='utf-8') as file:
                        lines = file.readlines()
                        for index, line in enumerate(lines):
                            if index >= max_lines:
                                print(f"경고! {file_path} 파일 크기 때문에 {max_lines}줄까지만 검사합니다.")
                                break
                            if line.startswith("#") or line.startswith("//"):
                                print(f"[주석] {file_path} {index+1}줄 탐지: {line.strip()}")
                            if re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", line):
                                print(f"[이메일] {file_path} {index+1}줄 탐지: {line.strip()}")
                except Exception as e:
                    print("에러가 발생하였습니다!")

            pre_files =  current_files #기존 파일에 넣어주면 result_diff는 항상 새로운 파일만 출력
            print("모니터링 ing ... ")
            time.sleep(2) #2초마다
    except KeyboardInterrupt:
        print("모니터링을 종료합니다!")

if __name__ == "__main__":
    monitoring_uploadsdir()
