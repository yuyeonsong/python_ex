import requests
from bs4 import BeautifulSoup

#url = "https://www.boannews.com/"
#url = "https://www.dailysecu.com/"
url = "https://zdnet.co.kr/"

#헤더 정보가 있어야 봇으로 의심받지 않는다(크롤링 탐지 방지)
header_info = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0'}
r = requests.get(url, headers=header_info) #get요청

soup = BeautifulSoup(r.text, 'html.parser') #html 파싱

#select 형식으로 copy한 내용 붙이기
#div:nth-child(1) 형식은 하나만 가져오므로 지운다
links = soup.select("body > div.contentWrapper > div > div.left_cont > div.news1_box > div.news_list > div > div.assetText > a > h4")

#print(link)
for link in links:
    print(f"{link.string}") #문자열만 가져오기