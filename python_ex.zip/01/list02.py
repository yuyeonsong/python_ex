# 아래는 5명의 학생들의 성적을 입력 받아서
# 최대값, 최소값, 평균값, 특정 점수(90점) 이상의 count 프로그램

# 1. 5명의 학생들의 성적을 입력받아 리스트에 저장

STUDENTS = 5 #고정된 값은 대문자 사용
lst = []
count = 0

for i in range(STUDENTS):
    value = int(input(f"{i+1}번째 학생의 성적을 입력하세요."))
    lst.append(value)

print(lst)

# 최대값, 최소값, 평균값 계산 max, min, sum
print(f"최대 점수: {max(lst)}")
print(f"최소 점수: {min(lst)}")
print(f"평균 점수: {sum(lst)/len(lst)}")

for score in lst:
    if score >= 90:
        count += 1
print(f"90점 이상의 학생의 수: {count}명")



