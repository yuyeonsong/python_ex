name = input("이름을 입력하세요.")
phone = input(f"{name}의 전화번호를 입력하세요.")
age = int(input("나이를 입력하세요."))

#print(name)
#print(phone)
#print(age)

print(name, "의 전화번호는", phone,"입니다.", "나이는", age)

#문자열 포맷팅
#% 사용, format()메서드 사용-인덱스 사용 가능
#f-string사용
print("내 이름은 {}이고 나이는 {}살입니다.".format(name,age))
print(f"내 이름은 {name}이고 나이는 {age}살입니다.")
