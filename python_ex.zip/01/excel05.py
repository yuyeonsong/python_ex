import requests
from bs4 import BeautifulSoup
from openpyxl import Workbook

url = "https://www.malware-traffic-analysis.net/2023/index.html"
headers = {
    'User-Agent': 'Mozilla/5.0',
    'Content-Type': 'text/html; charset=utf-8'
}
req = requests.get(url, headers=headers)
soup = BeautifulSoup(req.text, "lxml")

# 워크북 생성
wb = Workbook()
ws = wb.active

# 헤더 입력
ws.append(["설명", "URL 링크"])

# 링크 정보 추출 및 저장
tags = soup.select('#main_content > div.content > ul > li > a.main_menu')
for tag in tags:
    ws.append([tag.text, f"https://www.malware-traffic-analysis.net/2023/{tag['href']}"])

# 엑셀 파일 저장
wb.save("malwares1.xlsx")