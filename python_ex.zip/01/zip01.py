#zip01.py

import zipfile
import os

RESULT_DIR = 'uploads'

zip_file = zipfile.ZipFile('results.zip', 'w') #압축

#압축하는 경우 listdir보단 os.walk를 사용해서 모든 하위 디렉토리, 파일 탐색
for root, dirs, files in os.walk(RESULT_DIR):
    for file in files:
        #os.path.join()의 경로에 있는 파일을 zip에 추가
        zip_file.write(os.path.join(root, file))

zip_file.close()