# 'with' 문을 사용하여 파일을 열고 자동으로 닫기

#read()는 전체 파일을 읽으므로 내용 존재여부 확인은 좋으나 위치는 모름
#인덱스 개념이 없음
with open('example.txt', 'r', encoding='utf-8') as helloFile:
    content = helloFile.read()
    print(content)

print("==========================")
#readline()은 한줄씩 내용 가져옴
with open('example.txt', 'r', encoding='utf-8') as helloFile:
    content = helloFile.readline()
    print(content)
    content = helloFile.readline()
    print(content)

print("==========================")
#readlines()는 리스트 형식, 전체 내용 가져옴
#인덱스 추출 가능
with open('example.txt', 'r', encoding='utf-8') as helloFile:
    content = helloFile.readlines()
    print(content)
    #strip() 사용해 깔끔하게 보기
    for line in content:
        print(line.strip())
    #혹은 end 사용해 깔끔하게 보기
    for line in content:
        print(line, end='')