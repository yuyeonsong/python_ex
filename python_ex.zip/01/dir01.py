#디렉터리 트리 탐색
import os

for dirpath, dirnames, filenames in os.walk(r"C:\python_ex"):
    print(f"Found directory: {dirpath}")
    print(f"Subdir: {dirnames}")
    print(f"File: {filenames}")
    print("-"*50)