# 한글로 된 텍스트 파일 -> 영어로 번역을 합니다. (10줄 이내)
# 번역된 파일을 날짜를 더해서 저장
# 이메일로 보낸다.
import os
from datetime import datetime

from deep_translator import GoogleTranslator

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication 
from dotenv import load_dotenv

def mail_sender(report_file):
    load_dotenv()
    send_email = os.getenv("SECRET_ID")
    send_pwd = os.getenv("SECRET_PASS")
    recv_email = "binpageyu@naver.com" #보낼 계정

    smtp = smtplib.SMTP('smtp.naver.com', 587)
    smtp.ehlo()
    smtp.starttls()

    smtp.login(send_email,send_pwd)

    #html 형식 전송하기
    text = f"<html><b> Test Page </b></html>"
    
    #text = f"{report_file} 파일 번역 결과"

    msg = MIMEMultipart()
    msg['Subject'] = f"{day}{report_file} 파일 번역 결과"
    msg['From'] = send_email          
    msg['To'] = recv_email

    contentPart = MIMEText(text, 'html', 'utf-8') 
    #contentPart = MIMEText(text)
    msg.attach(contentPart) 

    etc_file_path = report_file #보낼 파일
    with open(etc_file_path, 'rb') as f : 
        etc_part = MIMEApplication( f.read() )
        etc_part.add_header('Content-Disposition','attachment', filename=etc_file_path)
        msg.attach(etc_part)

    smtp.sendmail(send_email,recv_email,msg.as_string() )
    smtp.quit()


now = datetime.now()
day = now.strftime("%Y-%m-%d")
hour = now.strftime("%H-%M-%S")

file_name = "uploads/3.txt"

with open(file_name, "r", encoding="UTF-8") as file:
    lines = file.read()
    translated = GoogleTranslator(source="ko", target="en").translate(lines)

# 번역 보고서 파일 생성
report_file = f"{file_name}_번역결과.txt"
with open(report_file, "a", encoding="UTF-8") as file:
    file.write(f"날짜: {day} 시간: {hour} 파일 내용 {file_name}\n")
    file.write(f"원문:\n{lines}\n")
    file.write(f"번역문:\n{translated}\n")   #번역된 것 추가

print(f"번역이 완료되었습니다. 결과는 {report_file}에 저장되었습니다.")
mail_sender(report_file)