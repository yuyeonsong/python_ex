import ftplib

def upload_file(ftp, filename):
    with open(filename, 'rb') as f: #smtp랑 같은 형식
        #1. storbinary 메서드 사용하기
        #ftp.storbinary('STOR ' + filename, f) #'STOR ' 한칸 꼭 띄어야 한다!
        ftp.storbinary(f'STOR {filename}', f) #f-string 방식(new!)

hostname = "192.168.244.128" #내 아이피
ftp = ftplib.FTP(hostname)
ftp.login('msfadmin','msfadmin')
upload_file(ftp, 'malwares.xlsx') #ftp전송

ftp.quit()

