import shodan
from pymongo import MongoClient

#쇼단 API 키
SHODAN_API_KEY = 't9v1GIKhVkV49QHr9O9sl0aqL1tj7kWe'
api = shodan.Shodan(SHODAN_API_KEY)

#DB 연결
client = MongoClient('mongodb://localhost:27017')
db = client['shodan_db']
collection = db['webcam_results']

#웹캠 검색
results = api.search('webcam')
print(f"검색 결과 : {results['total']}")

for match in results['matches'][:3]:
    data = {
        "ip": match['ip_str'],
        "port": match['port'],
        "org": match.get('org', 'n/a'),
        "location": match['location']['country_name'],
        "hostname": match['hostnames']
    }
    collection.insert_one(data)
    print(f"저장된 IP: {match['ip_str']}")