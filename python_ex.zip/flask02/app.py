from flask import Flask, render_template, request, send_file
import os
from openpyxl import load_workbook
from deep_translator import GoogleTranslator

app = Flask(__name__)

@app.route("/")
def index():
    return render_template('index.html')
    
@app.route("/upload", methods=['GET', 'POST']) #주소창에 입력될 경로 /upload
def upload():
    file = request.files['file']
    #저장한 뒤 번역
    file.save(os.path.join("uploads", file.filename)) #디렉토리 내 파일 객체 정보 중 이름 가져옴
    workbook = load_workbook(os.path.join("uploads", file.filename))
    sheet = workbook.active

    for row in sheet.iter_rows():
        for cell in row:
            translated_text = GoogleTranslator(source='ko', target='en').translate(cell.value)
            cell.value = translated_text

    workbook.save('result_en.xlsx')
    return render_template('result.html')

@app.route("/download_report")
def download_report():
    return send_file('result_en.xlsx', as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True) #개발자 모드